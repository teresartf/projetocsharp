namespace projetocsharp.Models{
public class NotaDeVenda
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public bool Tipo { get; set; }
    public List<Pagamento>? Pagamentos { get; set; }

    public int ClienteId { get; set; }

    public bool Cancelar()
    {
        return true;
    }

    public bool Devolver()
    {
        return true;
    }
}
}