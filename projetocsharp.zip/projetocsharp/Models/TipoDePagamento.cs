namespace projetocsharp.Models{
public class TipoDePagamento
{
    public int Id { get; set; }

    public string? NomeDoCobrador { get; set; }

    public string? InformacoesAdicionais { get; set; }
}
}