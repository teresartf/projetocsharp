namespace projetocsharp.Models{
public class Item
{
    public int Id { get; set; }

    public double Preco { get; set; }

    public int Percentual { get; set; }

    public int Quantidade { get; set; }

    public int ProdutoId { get; set; }
}
}