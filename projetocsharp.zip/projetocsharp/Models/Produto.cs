using System.ComponentModel.DataAnnotations;

namespace projetocsharp.Models{
public class Produto
{
    public int Id { get; set; }

    [Required]
    public string? Nome { get; set; }

    public string? Descricao { get; set; }

    public int Quantidade { get; set; }

    public double Preco { get; set; }

    public int MarcaId { get; set; }

    public List<Item>? Itens { get; set; }
}
}